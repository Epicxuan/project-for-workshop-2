import datetime,pymysql

import login as login
from flask import Flask, render_template, request, redirect
from wtforms import Form, BooleanField, StringField, PasswordField, validators
from flask_login import LoginManager, UserMixin, login_required, logout_user, login_user

app = Flask(__name__)
login_manager = LoginManager()
login_manager.init_app(app)
app.secret_key = b'my-secret-key'
from flask import Flask, render_template

app = Flask(__name__)

class DatabaseOperations():

# Fill in the information of your database server.
    __db_url = 'localhost'
    __db_username = 'root'
    __db_password = ''
    __db_name = 'test'
    __db = ''
    def __init__(self):
        """Connect to database when the object is created."""
        self.__db = self.db_connect()
    def __del__(self):
        """Disconnect from database when the object is destroyed."""
        self.__db.close()
    def db_connect(self):
        self.__db = pymysql.connect(self.__db_url, self.__db_username,
        self.__db_password, self.__db_name)
        return self.__db

    def getWord(self,word):
        cursor = self.__db.cursor()
        getword = """SELECT book_title FROM `test1_1` WHERE `word` = '%s' """ % word
        print("sql here")
        try:
            # Execute the SQL command
            cursor.execute(getword)
            # Fetch all the rows in a list of lists.
            results = cursor.fetchall()

            self.__db.commit()
            print(results)
            if len(results) > 0:
                print("have result")
                return results[0][0]
            else:
                result = 'No Matching Results'
                return result;
        except:
            print("Error")

@app.route('/', methods=['GET', 'POST'])
def SearchBox():
    result = ''
    if request.method == "POST":
        print('here')
        msg = request.form["text"]
        print(msg)
        result = DatabaseOperations().getWord(msg)
        return render_template('search.html',result=result)
    else:
        print('here2')
        result = ''
        return render_template('search.html',result=result)


